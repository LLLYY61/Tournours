import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user/user.service';
import { Router } from '@angular/router';
import { TournoteService } from '../../services/tournote/tournote.service';

declare var Swiper:any;
declare var $:any;
@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  constructor(public us:UserService,public router:Router,public ts:TournoteService) { }

  arts:Array<any>=[];
  userStatus:boolean=false;
  user:object={};
  
  //页面初始化
    ngOnInit() {
      var swiper=new Swiper(".swiper-container",{
        pagination:".swiper-pagination",
        paginationClickable:true,//分页器可点击
        loop:true,//循环模式
        autoplay:3000,//毫秒
        // autoplayDisableOnInteraction:true,
        paginationBulletRender: function (swiper, index, className) {
          return '<span class="' + className + '">' +`<img width=160 height=120 src="./assets/img/swiperImg/show0${index+1}.jpeg">` + '</span>';
        }
      })
      $(".toolbar").click(function(){
        var point=$(".swiper").offset();
				$("html,body").animate({
					scrollTop:point.top,
					scrollLeft:point.left
				},1000)
      });
      this.findAlltour();
    }

    // check(){
    //   //判断是否已登录
    //   this.us.checklogin().subscribe((data)=>{
    //     let result=data.json();
    //     this.userStatus=result.status;
    //     if(this.userStatus){
    //       this.user=result.user;
    //       this.router.navigate(['/tour']);
    //       return;
    //     }else{
    //       this.user={};
    //       alert("您还未登录,请登录!");
    //       this.router.navigate(['/login']);
    //     }
    //   });
    // }
    
    findAlltour(){
      this.ts.findByAll().subscribe((data)=>{
        let result=data.json();
        if(result.code=='success'){
          this.arts=result.data;
          return;
        }
        alert('无获取内容');
      })
    }
    
}

