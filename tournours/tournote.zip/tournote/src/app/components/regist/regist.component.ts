import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-regist',
  templateUrl: './regist.component.html',
  styleUrls: ['./regist.component.css']
})
export class RegistComponent implements OnInit {

  constructor(public user:UserService,public router:Router) { }
  userTel:string='';
  msg:string='';
  styleClass:string='';
  doRegist(){
    this.user.regist(this.userTel).subscribe((data)=>{
      let result=data.json();
      // console.log(result);
      this.msg=result.msg;
      this.styleClass=result.code;
      if(result.code=="success"){
        this.router.navigate(['/login']);
      }
    })
  }
  doFoucs(){
    this.msg="";
  }
  ngOnInit() {
  }

}


