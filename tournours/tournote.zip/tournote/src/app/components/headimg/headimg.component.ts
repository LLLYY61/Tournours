import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { UserService } from '../../services/user/user.service';
import { FileUploader } from '_ng2-file-upload@1.2.1@ng2-file-upload';
import { Set } from '../../extras/set';
declare var $: any;
@Component({
  selector: 'app-headimg',
  templateUrl: './headimg.component.html',
  styleUrls: ['./headimg.component.css']
})
export class HeadimgComponent implements OnInit {

  
  constructor(public us:UserService) { }
  userStatus:boolean=false;
  user:object={};
  imgUrl:string="";
  ngOnInit() {
    this.us.checklogin().subscribe((data)=>{
      let result=data.json();
      console.log(result);
      this.userStatus=result.status;
      if(this.userStatus){
        this.user=result.user;
        return;
      }else{
        this.user={};
      }
    });
  }

  uploader:FileUploader=new FileUploader({
    //上传地址
    url:"/tournours/fileUpload.php",
    //请求类型
    method:"POST",
    //上传文件key值
    itemAlias:"uploadedfile"
  });
  @ViewChild("file") myFile:ElementRef;
  set:Set=new Set(null,"");
  add(){
    //让图片能用file属性
    this.myFile.nativeElement.click(); 
  }
  selectFile(e){
    //this－>TourComponent
    let that=this;
    //文件渲染
    let reader=new FileReader();
    reader.readAsDataURL(e.target.files[0]);
    reader.onload=function(){
      //this->reader 
      that.imgUrl=this.result;
      $("#headImg").attr("src",that.imgUrl);
    }
  }
  public(){
    this.uploadImgFunction((data)=>{
      this.set.imgUrl=data.imgUrl;
      // console.log(this.set.imgUrl);
      this.us.change(this.set).subscribe((data)=>{
        // console.log(data.json());
      })
    })
  }
  uploadImgFunction(callback:Function){
    if(this.uploader.queue.length==0){
      console.log("没有待上传的文件");
      return;
    }
    //传的是最后被添加到队列的文件
    let index=this.uploader.queue.length-1;
    //定义上传回调函数，判断文件上传的结果或服务器的返回值
    this.uploader.queue[index].onSuccess=(response,status,headers)=>{
      if(status==200){
        //将参数传出去
        callback(JSON.parse(response));
      }else{
        console.log("服务器正忙");
      }
      window.location.reload(); 
    }
    //文件开始上传
    this.uploader.queue[index].upload();
    // window.location.reload();  
  } 
}
