import { Component, OnInit } from '@angular/core';
import { TogetherService } from '../../services/together/together.service';
import { ActivatedRoute } from '@angular/router';
import { Together } from '../../extras/together';

declare var $: any;
@Component({
  selector: 'app-together',
  templateUrl: './together.component.html',
  styleUrls: ['./together.component.css']
})
export class TogetherComponent implements OnInit {

  constructor(public tg:TogetherService,public ar:ActivatedRoute) { }
  dests:Array<any> =[];
  // d:number=0;
  // count:string="";
  // tid:string="";
  together:Together=new Together(null,"","","","","","","","","","","");
  ngOnInit() {
    // $("#day").html(parseInt((time1-time2)/(1000*3600)));
    // $("#day").html(parseInt(this.today-this.today1));
      // $(".trans").mouseover(function(){
      //   // $(".left").removeClass("left");
      //   $(".left").addClass("orangeleft");
      // })
      // $(".trans").mouseout(function(){
      //   $(".left").removeClass("orangeleft");
      //   $(".left").addClass("left");
      // })
   
    let dom = $("#datetext").datepicker({
        dateFormat:"yy/mm/dd",
        onClose:(dataText)=>{
          // console.log(dataText);
          this.together.startDate = dataText;
        }
    });

    $(".toolbar").click(function(){
      var point=$(".d1").offset();
      $("html,body").animate({
        scrollTop:point.top,
        scrollLeft:point.left
      },1000)
    });

    this.findAlltogether();

  }

  findAlltogether(){
    this.tg.findAll().subscribe((data)=>{
      let result=data.json();
      if(result.code=="success"){
        this.dests = result.data;
        for(let i=0;i<this.dests.length;i++){
          let d = 0;
          let dt=this.dests[i].startDate;
          let today=new Date(dt);
          let today1=new Date(); 
          let time1:number=today.getTime();
          let time2:number=today1.getTime();
          d=((time1-time2)/(1000*3600))/24;
          console.log(d);
          d=Math.ceil(d);
          // if(d<=0){
            // this.dests.splice(i,1);
            // console.log(this.dests);
            // continue;
          // }
          this.dests[i]['day'] = d;
          this.findCount(this.dests[i]);
        }
      }
    })
  }
  findCount(obj:Object)
  {
    this.tg.countNum(obj['tid']).subscribe((data)=>{
      let result=data.json();
      if(result.code=="success"){
        if(result.data==null){
          obj['count']="0";
        }
        obj['count']=result.data.tc;
        // console.log(obj);
        return;
      }
    })
  }


  dest:string;
  startDate:string;
  check(){
    this.tg.checkTogether(this.together).subscribe((data)=>{
      let result=data.json();
      if(result.code=="success"){
        this.dests = result.data;
        console.log(result);
        for(let i=0;i<this.dests.length;i++){
          // console.log(this.dests[i]);
          let d = 0;
          let dt=this.dests[i].startDate;
          let today=new Date(dt);
          let today1=new Date(); 
          let time1:number=today.getTime();
          let time2:number=today1.getTime();
          d=((time1-time2)/(1000*3600))/24;
          d=Math.ceil(d);
          // if(d<=0){
          //   d=0;
          //   // this.dests.shift();
          //   console.log(this.dests);
          // }
          this.dests[i]['day'] = d;
          this.findCount(this.dests[i]);
        }
      }
    })
  }
    
}
