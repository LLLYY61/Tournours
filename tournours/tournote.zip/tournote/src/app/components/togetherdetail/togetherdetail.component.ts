import { Component, OnInit } from '@angular/core';
import { Together } from '../../extras/together';
import { TogetherService } from '../../services/together/together.service';
import { togetherDetail } from '../../extras/togetherDetail';
import { ActivatedRoute } from '@angular/router';
import { TogetherJoin } from '../../extras/togetherJoin';

declare var $:any;
@Component({
  selector: 'app-togetherdetail',
  templateUrl: './togetherdetail.component.html',
  styleUrls: ['./togetherdetail.component.css']
})
export class TogetherdetailComponent implements OnInit {
  constructor(public tg:TogetherService,public ar:ActivatedRoute) { }

  tid:string="";
  number:string="";
  tel:string="";
  male:string="";
  female:string="";
  together:Together=new Together("","","","","","","","","","","","");
  join:Array<any>=[];
  count:string="";
  ngOnInit() {
    $(".toolbar").click(function(){
      var point=$(".d1").offset();
      $("html,body").animate({
        scrollTop:point.top,
        scrollLeft:point.left
      },1000)
    });


    let tid=this.ar.snapshot.params['tid'];
    this.findTogetherById(tid);
    this.tid=tid;
    this.findJoin(tid);
    this.findCount(tid);
  }


  findTogetherById(tid:string){
    this.tg.findById(tid).subscribe((data)=>{
      let result=data.json();
      if(result.code=="success"){
        this.together=result.data;
        // console.log(result.data);
        return;
      }
    })
  }

  publish(){
    let togetherJoin=new TogetherJoin(this.tid,this.number,this.tel,this.male,this.female);
    this.tg.joinIn(togetherJoin).subscribe((data)=>{
      let result=data.json();
      if(result.code=="success"){
        // window.location.reload();
        this.findJoin(this.tid);
        this.findCount(this.tid);
        return;
      }
    })
  }

  findJoin(tid:string){
    this.tg.findJoin(tid).subscribe((data)=>{
      let result=data.json();
      if(result.code=="success"){
        this.findTogetherById(tid);
        this.join=result.data;
        return;
      }
    })
  }

  findCount(tid:string)
  {
    this.tg.countNum(tid).subscribe((data)=>{
      let result=data.json();
      let c=result.data;
      if(result.code=="success"){
        if(result.data==null){
          this.count="0";
        }
        this.count=result.data.tc;
        console.log(this.count);
        return;
      }
    })
  }
}
