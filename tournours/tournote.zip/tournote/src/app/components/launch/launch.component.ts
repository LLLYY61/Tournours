import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { TogetherService } from '../../services/together/together.service';
import { FileUploader } from '_ng2-file-upload@1.2.1@ng2-file-upload';
import { Together } from '../../extras/together';
import { Router } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-launch',
  templateUrl: './launch.component.html',
  styleUrls: ['./launch.component.css']
})
export class LaunchComponent implements OnInit {

  imgUrl:string="./assets/img/add.png";
  
  constructor(public tg:TogetherService,public router:Router) { 
  }
  ngOnInit() {
    let dom = $("#datetext").datepicker({
        dateFormat:"yy/mm/dd",
        onClose:(dataText)=>{
          // console.log(dataText);
          this.together.startDate = dataText;
        }
    });
    $(".toolbar").click(function(){
      var point=$(".text").offset();
      $("html,body").animate({
        scrollTop:point.top,
        scrollLeft:point.left
      },1000)
    }) 
  }
  uploader:FileUploader=new FileUploader({
    //上传地址
    url:"/tournours/fileUpload.php",
    //请求类型
    method:"POST",
    //上传文件key值
    itemAlias:"uploadedfile"
  });

  @ViewChild("file") myFile:ElementRef;

  add(){
    //让图片能用file属性
    this.myFile.nativeElement.click();
  }
  selectFile(e){
    let that=this;
    //文件渲染
    let reader=new FileReader();
    reader.readAsDataURL(e.target.files[0]);
    reader.onload=function(){
      //this->reader 
      that.imgUrl=this.result;

    }
  }
  
  together:Together=new Together(null,"","","","","","","","","","","");
  public(){
    this.uploadImgFunction((data)=>{
      this.together.coverImg=data.imgUrl;
      // console.log(this.together.coverImg);
      this.tg.add(this.together).subscribe((data)=>{
        let result=data.json();
        // console.log(result);
        this.router.navigate(['/together']);
      })
    })
  }
  uploadImgFunction(callback:Function){
    if(this.uploader.queue.length==0){
      console.log("没有待上传的文件");
      return;
    }
    //传的是最后被添加到队列的文件
    let index=this.uploader.queue.length-1;
    //定义上传回调函数，判断文件上传的结果或服务器的返回值
    this.uploader.queue[index].onSuccess=(response,status,headers)=>{
      if(status==200){
        // let temp=JSON.parse(response);
        // console.log(response);
        //将参数传出去
        callback(JSON.parse(response));
      }else{
        console.log("服务器正忙");
      }
    }
    //文件开始上传
    this.uploader.queue[index].upload();
  }
}
