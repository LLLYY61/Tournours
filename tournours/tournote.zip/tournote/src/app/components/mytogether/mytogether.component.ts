import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mytogether',
  templateUrl: './mytogether.component.html',
  styleUrls: ['./mytogether.component.css']
})
export class MytogetherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  texts:Array<any>=[
    {"text":"2017年夏天过春节，纯净新西兰14天2500公里自驾游",
     "data":"出发地：兰州  出发时间：2017-10-1  目的地：四川青海|甘肃|甘南  大约：7天"
    },
    {"text":"2017年夏天过春节，纯净新西兰14天2500公里自驾游",
    "data":"出发地：兰州  出发时间：2017-10-1  目的地：四川青海|甘肃|甘南  大约：7天"
   },
   {"text":"2017年夏天过春节，纯净新西兰14天2500公里自驾游",
   "data":"出发地：兰州  出发时间：2017-10-1  目的地：四川青海|甘肃|甘南  大约：7天"
  },
  {"text":"2017年夏天过春节，纯净新西兰14天2500公里自驾游",
  "data":"出发地：兰州  出发时间：2017-10-1  目的地：四川青海|甘肃|甘南  大约：7天"
 },
  ]
}
