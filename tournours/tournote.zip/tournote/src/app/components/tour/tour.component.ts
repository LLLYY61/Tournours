import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FileUploader } from '_ng2-file-upload@1.2.1@ng2-file-upload';
import { TournoteService } from '../../services/tournote/tournote.service';
import { UEditorComponent } from '_ngx-ueditor@1.0.7@ngx-ueditor';
import { Tour } from '../../extras/tour';
import { Router } from '@angular/router';

declare var $:any;

@Component({
  selector: 'app-tour',
  templateUrl: './tour.component.html',
  styleUrls: ['./tour.component.css']
})

export class TourComponent implements OnInit {

  //默认图片路径
  imgUrl:string="./assets/img/page_default.jpg";
  //将TournoteService服务注入
  constructor(public ts:TournoteService,public router:Router) { }

  ngOnInit() { 
    $(".toolbar").click(function(){
      var point=$(".d1").offset();
      $("html,body").animate({
        scrollTop:point.top,
        scrollLeft:point.left
      },1000)
    })
  }

  uploader:FileUploader=new FileUploader({
    //上传地址
    url:"/tournours/fileUpload.php",
    //请求类型
    method:"POST",
    //上传文件key值
    itemAlias:"uploadedfile"
  });

  //获取input的id
  @ViewChild("file") myFile:ElementRef;

  add(){
    //让图片能用file属性
    this.myFile.nativeElement.click();
  }
  selectFile(e){
    //this－>TourComponent
    let that=this;
    //文件渲染
    let reader=new FileReader();
    reader.readAsDataURL(e.target.files[0]);
    reader.onload=function(){
      //this->reader 
      that.imgUrl=this.result;
    }
    $(".add").addClass("hid");
    $(".p1").addClass("hid");
    $(".p2").addClass("hid");
  }

  //获取ueditor的id
  @ViewChild("ue") ue:UEditorComponent;
  tour:Tour=new Tour(null,"","","","","","","");
  public(){
    //反射 获取ueditor的内容并赋值给tour.content
    this.tour.content=this.ue.Instance.getContent();
    //获取上传后的PHP路径
    this.uploadImgFunction((data)=>{
      this.tour.contentImg=data.imgUrl;
      //发布内容
      this.ts.publish(this.tour).subscribe((data)=>{
        console.log(data.json());
        // let result=data.json();
        this.router.navigate(['/main']);
      })
    })

  }
  //回调函数
  uploadImgFunction(callback:Function){
    if(this.uploader.queue.length==0){
      console.log("没有待上传的文件");
      return;
    }
    //传的是最后被添加到队列的文件
    let index=this.uploader.queue.length-1;
    //定义上传回调函数，判断文件上传的结果或服务器的返回值
    this.uploader.queue[index].onSuccess=(response,status,headers)=>{
      if(status==200){
        // let temp=JSON.parse(response);
        // console.log(response);
        //将参数传出去
        callback(JSON.parse(response));
      }else{
        console.log("服务器正忙");
      }
    }
    //文件开始上传
    this.uploader.queue[index].upload();
  }

    cfg={
      toolbars: [[
        'undo', 'redo', '|',
        'bold', 'italic', 'underline', 'removeformat',  'autotypeset', 'blockquote', '|', 'forecolor', 'backcolor', 'insertorderedlist', 'insertunorderedlist', '|',
        'rowspacingtop', 'rowspacingbottom', 'lineheight', '|',
        'customstyle', 'paragraph', 'fontfamily', 'fontsize', '|',
        'justifyleft', 'justifycenter', 'justifyright', 'justifyjustify', '|',
        'simpleupload', 'insertimage', 'emotion', 'scrawl', '|',  'date', 'time',
        'inserttable', 'deletetable', 'insertparagraphbeforetable', 'insertrow', 'deleterow', 'insertcol', 'deletecol', 'mergecells', 'mergeright', 'mergedown', 'splittocells', 'splittorows', 'splittocols',  '|', 
      ]]
    }
}
