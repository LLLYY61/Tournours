import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user/user.service';
import { num } from '../../extras/num';
import { setPassword } from '../../extras/setpassword';

@Component({
  selector: 'app-passward',
  templateUrl: './passward.component.html',
  styleUrls: ['./passward.component.css']
})
export class PasswardComponent implements OnInit {

  constructor(public us:UserService) { }

  

  ngOnInit() {
  }
  getNum(){
    this.us.getNum().subscribe((data)=>{
      let result=data.json();
      // console.log(result.data);
      alert(result.data);
    })
  }
  password:string="";
  repassword:string="";
  num:string="";
  msg:string="";
  setpassword:setPassword=new setPassword(null,"","","");
  change(){
    this.us.changePassword(this.setpassword).subscribe((data)=>{
      let result=data.json();
      this.msg=result.msg;
      alert(this.msg);
    })
  }
}
