import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mytour',
  templateUrl: './mytour.component.html',
  styleUrls: ['./mytour.component.css']
})
export class MytourComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  texts:Array<any>=[
    {"text":"2017年夏天过春节，纯净新西兰14天2500公里自驾游"},
    {"text":"2017年夏天过春节，纯净新西兰14天2500公里自驾游"},
    {"text":"2017年夏天过春节，纯净新西兰14天2500公里自驾游"},
    {"text":"2017年夏天过春节，纯净新西兰14天2500公里自驾游"},
  ]
}
