import { Component, OnInit } from '@angular/core';
import { TournoteService } from '../../services/tournote/tournote.service';
import { Tour } from '../../extras/tour';
import { ActivatedRoute } from '@angular/router';
import { CommentService } from '../../services/comment/comment.service';
import {CommentObject} from '../../extras/commentObject';

declare var $:any;
@Component({
  selector: 'app-tourdetail',
  templateUrl: './tourdetail.component.html',
  styleUrls: ['./tourdetail.component.css']
})
export class TourdetailComponent implements OnInit {

  constructor(public ar:ActivatedRoute,public ts:TournoteService,public cs:CommentService) { }

  context:string="";
  tid:string="";
  tour:Tour=new Tour(null,"","","","","","","");
  comments:Array<any>=[];

  ngOnInit() {
    $(".toolbar").click(function(){
      var point=$(".d1").offset();
      $("html,body").animate({
        scrollTop:point.top,
        scrollLeft:point.left
      },1000)
    });

    let tid=this.ar.snapshot.params['tid'];
    this.findTourById(tid);
    this.tid=tid;
    this.findCommentByTourId(tid);
    
  }
  

  findTourById(tid:string){
    this.ts.findNoteDetailById(tid).subscribe((data)=>{
      let result=data.json();
      if(result.code=="success"){
        this.tour=result.data;
        return;
      }
   })
}
addComment(){
    let commentObject=new CommentObject(this.context,this.tid,"","","");
    this.cs.addComment(commentObject).subscribe((data)=>{
      let result=data.json();
      if(result.code=="success"){
        // console.log(result);
        return;
      }
    })
  }
  
  findCommentByTourId(tid:string){
    this.cs.findCommentByTourId(tid).subscribe((data)=>{
      let result=data.json();
      if(result.code=="success"){
        console.log(result);
        this.findCommentByTourId(tid);
        this.comments=result.data;
      }
    })
  }
}
