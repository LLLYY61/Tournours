import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(public user:UserService,public router:Router) { }

  userTel:string='';
  password:string='';
  msg:string='';
  Msg:string='';
  styleClass:string='';
  
  doLogin(){
    this.user.login(this.userTel,this.password).subscribe((data)=>{
        let result=data.json();
        
        this.styleClass=result.code;
        if(result.msg=="密码错误"){
          this.Msg=result.msg;
        }
        if(result.msg=="该手机号未进行注册"){
          this.msg=result.msg;
        }
        if(result.code=="success"){
          this.router.navigate(['/']);
        }
        
    })

  }
  telBlur(){
    this.msg="";
  }
  pwdBlur(){
    this.Msg="";
  }
  ngOnInit() {
  }

}
