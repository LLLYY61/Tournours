import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user/user.service';
import { Setname } from '../../extras/setname';


@Component({
  selector: 'app-info',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.css']
})
export class InfoComponent implements OnInit {

  constructor(public us:UserService) { }

  ngOnInit() {
  }
  name:string="";
  sex:string="";
  msg:string="";
  setname:Setname=new Setname(null,"");
  change(){
    this.us.changeName(this.setname).subscribe((data)=>{
      let result=data.json();
      this.msg=result.msg;
      if(this.msg=='修改成功！'){
        alert("修改成功！");
      }
    })
  }
}
