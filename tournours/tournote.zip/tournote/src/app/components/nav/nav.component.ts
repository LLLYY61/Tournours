import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})

export class NavComponent implements OnInit {
   //注入UserService
  constructor(public us:UserService,public router:Router) { }
  userStatus:boolean=false;
  user:object={};

  ngOnInit() {
    // 判断是否已登录
    this.us.checklogin().subscribe((data)=>{
      let result=data.json();
      console.log(result);
      this.userStatus=result.status;
      if(this.userStatus){
        this.user=result.user;
        return;
      }else{
        this.user={};
      }
    });
  }
  
  quit(){
    this.us.quit().subscribe((data)=>{
        let result=data.json();
        // this.user=result.user;
        this.userStatus=result.status;
        if(this.userStatus){
          this.user={};
          this.router.navigate(['/']);
          return;
        }else{
          this.user=result.user;
        } 
    })
  }
}
