import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http ,URLSearchParams} from '@angular/http';
import { Set } from '../../extras/set';
import { Setname } from '../../extras/setname';
import { num } from '../../extras/num';
import { setPassword } from '../../extras/setpassword';




@Injectable()
export class UserService {

  constructor(public http:Http) { }

  public login(tel:string,password:string):Observable<any>{
    let params=new URLSearchParams();
    params.append("tel",tel);
    params.append("password",password);
    return this.http.post("/tournours/loginUser.php",params);
  }

  public regist(tel:string):Observable<any>{
    let params=new URLSearchParams();
    params.append("tel",tel);
    return this.http.post("/tournours/registUser.php",params);
  }

  public checklogin():Observable<any>{
    return this.http.get("/tournours/checkLogin.php");
  }
  public quit():Observable<any>{
    return this.http.get("/tournours/quit.php")
  }
  public change(set:Set):Observable<any>{
    let params=new URLSearchParams();
    params.append("imgUrl",set.imgUrl);
    return this.http.post("/tournours/changeheadImg.php",params);
  }
  public changeName(setname:Setname):Observable<any>{
    let params=new URLSearchParams();
    params.append("name",setname.name);
    return this.http.post("/tournours/changeName.php",params);
  }
  public getNum():Observable<any>
  {
    // let params=new URLSearchParams();
    // params.append("num",num.num);
    return this.http.get("/tournours/num.php");
  }
  public changePassword(setpassword:setPassword):Observable<any>
  {
    let params=new URLSearchParams();
    // params.append("id",setpassword.id);
    params.append("password",setpassword.password);
    params.append("repassword",setpassword.repassword);
    params.append("num",setpassword.num);
    return this.http.post("/tournours/changePassword.php",params);
  }
}
