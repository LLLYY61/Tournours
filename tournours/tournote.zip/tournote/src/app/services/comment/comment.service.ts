import { Injectable } from '@angular/core';
import {Comment} from "../../extras/comment"
import { Observable } from 'rxjs/Observable';
import { CommentObject } from '../../extras/commentObject';
import { Http ,URLSearchParams} from '@angular/http';
@Injectable()
export class CommentService {

  constructor(public http:Http) { }


  public addComment(comment:CommentObject):Observable<any>
  {
    let params=new URLSearchParams();
    params.append("content",comment.content);
    params.append("tid",comment.tid);
    return this.http.post("/tournours/addComment.php",params);
  }

  public findCommentByTourId(tid:string):Observable<any>
  {
    let params=new URLSearchParams();
    params.append("tid",tid);
    return this.http.post("/tournours/findCommentByTourId.php",params);
  }

}
