import { Injectable } from '@angular/core';
import { Together } from '../../extras/together';
import { Observable } from 'rxjs/Observable';
import { Http,URLSearchParams } from '@angular/http';
import { TogetherJoin } from '../../extras/togetherJoin';
import { countNum } from '../../extras/countNum';

@Injectable()
export class TogetherService {

  constructor(private http:Http) { }

  public add(together:Together):Observable<any>{
    let params=new URLSearchParams();
    params.append('title',together.title);
    params.append('tel',together.tel);
    params.append('qq',together.qq);
    params.append('weixin',together.weixin);
    params.append('to',together.to);
    params.append('from',together.from);
    params.append('startDate',together.startDate);
    params.append('lastDays',together.lastDays);
    params.append('limitNum',together.limitNum);
    params.append('intro',together.intro);
    params.append('coverImg',together.coverImg);
    return this.http.post("/tournours/together.php",params);
    // params.append('joinInUsers',together.joinInUsers);
  }

  public list(pageNo:number=1):Observable<any> // Array<Together>
  {
    return null;
  }

  public findAll():Observable<any>
  {
    return this.http.get("/tournours/findAlltogether.php");
  }

  public findById(id:string):Observable<any>// Together
  {
    let params=new URLSearchParams();
    params.append("tid",id);
    return this.http.post("/tournours/findTogetherById.php",params);
  }

  public joinIn(togetherJoin:TogetherJoin):Observable<any>
  {
    let params=new URLSearchParams();
    params.append("tid",togetherJoin.tid);
    params.append("male",togetherJoin.male);
    params.append("female",togetherJoin.female);
    params.append("tel",togetherJoin.tel);
    params.append("number",togetherJoin.number);
    return this.http.post("/tournours/togetherJoin.php",params);
  }

  public findJoin(tid:string):Observable<any>
  {
    let params=new URLSearchParams();
    params.append("tid",tid);
    return this.http.post("/tournours/findJoin.php",params);
  }

  public countNum(tid:string):Observable<any>
  {
    let params=new URLSearchParams();
    params.append("tid",tid);
    return this.http.post("/tournours/countNum.php",params);
  }

  public checkTogether(together:Together):Observable<any>
  {
    let params=new URLSearchParams();
    params.append("dest",together.from);
    params.append("startDate",together.startDate);
    return this.http.post("/tournours/checkTogether.php",params);
  }
}
