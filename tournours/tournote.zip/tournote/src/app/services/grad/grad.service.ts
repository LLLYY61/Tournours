import { Injectable } from '@angular/core';
import { UserService } from '../user/user.service';
import { CanActivate,Router } from '@angular/router';

@Injectable()
export class GradService implements CanActivate {

  constructor(public us:UserService,public router:Router) { }
  canActivate(){
    let flag=false;
    return new Promise<boolean>((resolved,rejected)=>{
      this.us.checklogin().subscribe((data)=>{
        let result=data.json();
        if(!result.status){
          alert("您还未登录，请先登录！");
          this.router.navigate(["/login"]);
        }
        resolved(result.status);
      });
    });
  };
}
