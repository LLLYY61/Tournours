import { TestBed, inject } from '@angular/core/testing';

import { GradService } from './grad.service';

describe('GradService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GradService]
    });
  });

  it('should be created', inject([GradService], (service: GradService) => {
    expect(service).toBeTruthy();
  }));
});
