import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './components/main/main.component';
import { LoginComponent } from './components/login/login.component';
import { RegistComponent } from './components/regist/regist.component';
import { TogetherComponent } from './components/together/together.component';
import { TogetherdetailComponent } from './components/togetherdetail/togetherdetail.component';
import { LaunchComponent } from './components/launch/launch.component';
import { TourComponent } from './components/tour/tour.component';
import { TourdetailComponent } from './components/tourdetail/tourdetail.component';
import { SetComponent } from './components/set/set.component';
import { InfoComponent } from './components/info/info.component';
import { HeadimgComponent } from './components/headimg/headimg.component';
import { PasswardComponent } from './components/passward/passward.component';
import { PublicComponent } from './components/public/public.component';
import { MytourComponent } from './components/mytour/mytour.component';
import { MytogetherComponent } from './components/mytogether/mytogether.component';
import { AppComponent } from './app.component';
import { NavComponent } from './components/nav/nav.component';
import { GradService } from './services/grad/grad.service';

const routes: Routes = [
  {path:'',component:NavComponent,children:[
      {path:'',component:MainComponent},
      {path:"main",component:MainComponent},
      {path:"together",component:TogetherComponent},
      {path:"detail/:tid",component:TogetherdetailComponent,canActivate:[GradService]},
      {path:"launch",component:LaunchComponent,canActivate:[GradService]},
      {path:"tour",component:TourComponent,canActivate:[GradService]},
      {path:"tourdetail/:tid",component:TourdetailComponent},
      {path:"set",component:SetComponent,children:[
          {path:"",component:InfoComponent},
          {path:"info",component:InfoComponent},
          {path:"headImg",component:HeadimgComponent},
          {path:"passward",component:PasswardComponent},
      ]},
      {path:"public",component:PublicComponent,children:[
          {path:"",component:MytourComponent},
          {path:"mytour",component:MytourComponent},
          {path:"mytogether",component:MytogetherComponent},
        ]}
  ]}, 
    {path:"login",component:LoginComponent},
    {path:"regist",component:RegistComponent},  
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
