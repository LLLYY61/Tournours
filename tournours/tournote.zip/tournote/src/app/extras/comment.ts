export class Comment{

    constructor(
        public name:string,
        public imgUrl:string,
        public content:string,
        public pubDate:string
    )
    {

    }

}