export class setPassword{
    constructor(
        public id:number,
        public password:string,
        public repassword:string,
        public num:string   
    )
    {

}
    
}