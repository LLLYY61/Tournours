export class countNum{
    
        constructor(
            public tid:string,
            public count:string,
        )
        {
    
        }
    
    }