export class Tour{
    constructor(
        public id:number,
        public title:string,
        public content:string,
        public contentImg:string,
        public type:string,
        public publishDate:string,
        public author:string,
        public authorImg:string){
    }
}