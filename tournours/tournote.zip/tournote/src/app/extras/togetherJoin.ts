export class TogetherJoin{
    constructor(
        public tid:string,
        public number:string,
        public tel:string,
        public male:string,
        public female:string
        )
    { }   
}