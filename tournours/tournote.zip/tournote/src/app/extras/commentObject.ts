export class CommentObject{
    constructor(
        public content:string,
        public tid:string,
        public name:string,
        public imgUrl:string,
        public pubDate:string
        )
    { }   
}