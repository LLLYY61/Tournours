export class num{
    constructor(
        // public id:number,
        public num:string,   
        )
    { }  
}