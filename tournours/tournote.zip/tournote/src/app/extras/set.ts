export class Set{
    
    constructor(
        public id:number,
        public imgUrl:string,
       
    )
    {

    }
    
}