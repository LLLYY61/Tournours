export class Together{
    constructor(
        public id:string,
        public title:string,
        public tel:string,
        public qq:string,
        public weixin:string,
        public to:string,
        public from:string,
        public startDate:string,
        public lastDays:string,
        public limitNum:string,
        public intro:string,
        public coverImg:string
       )
    {}
}