export class togetherDetail{
    constructor(
        public tid:string,
        public title:string,
        public tel:string,
        public qq:string,
        public weixin:string,
        public toCity:string,
        public fromCity:string,
        public startDate:string,
        public lastDays:string,
        public limitNum:string,
        public intro:string,
        public coverImg:string,
        public nikeName:string,
        public userImgUrl:string
       )
    {}
}