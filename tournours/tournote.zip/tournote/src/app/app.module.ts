import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';
import { FileUploadModule } from '../../node_modules/_ng2-file-upload@1.2.1@ng2-file-upload'

import { MainComponent } from './components/main/main.component';
import { LoginComponent } from './components/login/login.component';
import { RegistComponent } from './components/regist/regist.component';
import { TogetherComponent } from './components/together/together.component';
import { TogetherdetailComponent } from './components/togetherdetail/togetherdetail.component';
import { LaunchComponent } from './components/launch/launch.component';
import { TourComponent } from './components/tour/tour.component';
import { UEditorModule,UEditorConfig} from 'ngx-ueditor';
import { TourdetailComponent } from './components/tourdetail/tourdetail.component';
import { SetComponent } from './components/set/set.component';
import { InfoComponent } from './components/info/info.component';
import { HeadimgComponent } from './components/headimg/headimg.component';
import { PasswardComponent } from './components/passward/passward.component';
import { PublicComponent } from './components/public/public.component';
import { MytourComponent } from './components/mytour/mytour.component';
import { MytogetherComponent } from './components/mytogether/mytogether.component';
import { UserService } from './services/user/user.service';
import { NavComponent } from './components/nav/nav.component';
import { CommonModule } from '@angular/common';
import { TournoteService } from './services/tournote/tournote.service';
import { TogetherService } from './services/together/together.service';
import { CommentService } from './services/comment/comment.service';
import { GradService } from './services/grad/grad.service';

@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    LoginComponent,
    RegistComponent,
    TogetherComponent,
    TogetherdetailComponent,
    LaunchComponent,
    TourComponent,
    TourdetailComponent,
    SetComponent,
    InfoComponent,
    HeadimgComponent,
    PasswardComponent,
    PublicComponent,
    MytourComponent,
    MytogetherComponent,
    NavComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule,
    UEditorModule,
    CommonModule,
    FileUploadModule
  ],
  providers: [
    UserService,
    TournoteService,
    UEditorConfig,
    TogetherService,
    CommentService,
    GradService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
