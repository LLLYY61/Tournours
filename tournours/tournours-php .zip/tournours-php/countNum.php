<?php
    require "util/dbUtil.php";
    $resultArr=Array();
    session_start();
    $tid=$_REQUEST["tid"];

    $user=$_SESSION["user"];
    $userId=$user["id"];
    if($user==''){
        echo json_encode(array('code'=>'error','msg'=>'该用户还未进行登录，请登录'));
        return;
    };

    $sql="
        select 
            count(*) tc
        from
            t_together_join t
        where
            togetherId='{$tid}'
        group by 
            togetherId
    ";
    $result=mysqli_query($conn,$sql);
    $countNum=mysqli_fetch_array($result,MYSQLI_ASSOC);
    echo json_encode(array('code'=>'success','data'=>$countNum));