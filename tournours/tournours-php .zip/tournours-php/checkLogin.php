<?php
    require "util/dbUtil.php";
    session_start();
    $user=$_SESSION["user"];
    // print_r($user);
    $resultArr=Array();
    //未有用户登录
    if($user==""){
        $resultArr["status"]=false;
        $resultArr["user"]="";
        echo json_encode($resultArr);
        return;
    }

        $resultArr["status"]=true;
        $resultArr["user"]=$user;
        echo json_encode($resultArr);
        return;
    