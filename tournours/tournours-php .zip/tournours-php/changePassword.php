<?php
    require "util/dbUtil.php";
    session_start();
    $password=$_REQUEST["password"];
    $repassword=$_REQUEST["repassword"];
    $num=$_REQUEST["num"];

    $user=$_SESSION["user"];
    $userId=$user["id"];
    if($user==''){
        echo json_encode(array('code'=>'error','msg'=>'该用户还未进行登录，请登录'));
        return;
    };
    if($password != $repassword){
        echo json_encode(array('code'=>'error','msg'=>'新密码与重复密码不一致'));
        return;
    };

    $sql="
        update 
            t_user
        set
            password='{$password}'
        where
            id='{$userId}'
    ";
    $result=mysqli_query($conn,$sql);

    $sql="
        select 
            id,nikeName,userTel,password,userImgUrl
        from 
            t_user
        where 
            id='{$userId}'    
    ";
    $result=mysqli_query($conn,$sql);
    $user=mysqli_fetch_array($result,MYSQLI_ASSOC);
    $_SESSION["user"]=$user;
    echo json_encode(array('code'=>'success','msg'=>'修改成功！'));
