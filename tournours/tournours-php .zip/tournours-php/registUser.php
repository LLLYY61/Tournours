<?php
    require "util/dbUtil.php";

    $userTel=$_REQUEST["tel"];

    $resultArr=Array();
    //先进行判断手机号是否为空
    if($userTel==""){
        $resultArr["code"] = "error";
        $resultArr["msg"] = "手机号不能为空";
        echo json_encode($resultArr);
        return;
    };
    
    //判断手机号是否已存在
    $sql="
        select 
            id,nikeName,userTel,password,userImgUrl
        from 
            t_user
        where 
            userTel='{$userTel}'
    ";
   
    $result=mysqli_query($conn,$sql);
    //查询结果中是否有多条数据返回，若有多条则代表已存在
    if($result ->num_rows >0){
        $resultArr["code"] = "error";
        $resultArr["msg"] = "手机号已存在";
        echo json_encode($resultArr);
        return;
    };
    
    //nikeName,password,userImgUrl设置默认值
    $nikeName="无名氏";
    $password=rand(100000,999999);
    $userImgUrl="user/user.jpeg";

    //将输入内容插入数据库
    $sql="
        insert into 
            t_user
        (nikeName,userTel,password,userImgUrl)
            values
        ('{$nikeName}','{$userTel}','{$password}','{$userImgUrl}')
    ";

    $result=mysqli_query($conn,$sql);

    $resultArr["code"] = "success";
    $resultArr["msg"] = "注册成功";
    $resultArr["密码"] = $password;
    
    echo json_encode($resultArr);
