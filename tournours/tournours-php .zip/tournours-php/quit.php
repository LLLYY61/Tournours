<?php
    require "util/dbUtil.php";
    session_start();
    $user=$_SESSION["user"];
    $resultArr=Array();
    session_destroy();
    $resultArr["user"]=$user;
    echo json_encode($resultArr);