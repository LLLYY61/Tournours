<?php
    require "util/dbUtil.php";
    // $resultArr=Array();
    session_start();
    $imgUrl=$_REQUEST["imgUrl"];
    $user=$_SESSION["user"];
    $userId=$user["id"];
    if($user==''){
        echo json_encode(array('code'=>'error','msg'=>'该用户还未进行登录，请登录'));
        return;
    };
    $sql="
        update t_user
            set
        userImgUrl='{$imgUrl}'
            where id='{$userId}'
    ";
    $result=mysqli_query($conn,$sql);
    // echo json_encode(array('code'=>'success','msg'=>'更新成功'));
    $sql="
        select 
            id,nikeName,userTel,password,userImgUrl
        from 
            t_user
        where 
        id='{$userId}'    
    ";
    $result=mysqli_query($conn,$sql);
    $user=mysqli_fetch_array($result,MYSQLI_ASSOC);
    // $resultArr["user"]=$user;
    $_SESSION["user"]=$user;
    // echo json_encode($resultArr);
    echo json_encode(array('code'=>'success','msg'=>'修改成功！'));