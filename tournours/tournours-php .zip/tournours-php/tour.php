<?php
    require "util/dbUtil.php";
    session_start();
    $title=$_REQUEST["title"];
    $type=$_REQUEST["type"];
    $content=$_REQUEST["content"];
    $contentImg=$_REQUEST["contentImg"];

    $user=$_SESSION["user"];
    $userId=$user["id"];
    //判断用户是否登录
    if($user==''){
        echo json_encode(array('code'=>'error','msg'=>'该用户还未进行登录，请登录'));
        return;
    };
    
    $sql="
        insert into t_tour
            (title,content,contentImg,type,publishDate,userId)
        values
            ('{$title}','{$content}','{$contentImg}','{$type}',now(),'{$userId}')
    ";

    $result = mysqli_query($conn,$sql);
    echo json_encode(array('code'=>'success','msg'=>'发布游记成功'));
