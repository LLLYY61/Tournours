<?php
    require "util/dbUtil.php";
    // print_r($_REQUEST);
    session_start();
    $title=$_REQUEST["title"];
    $tel=$_REQUEST["tel"];
    $qq=$_REQUEST["qq"];
    $weixin=$_REQUEST["weixin"];
    $to=$_REQUEST["to"];
    $from=$_REQUEST["from"];
    $startDate=$_REQUEST["startDate"];
    $lastDays=$_REQUEST["lastDays"];
    $limitNum=$_REQUEST["limitNum"];
    $intro=$_REQUEST["intro"];
    $coverImg=$_REQUEST["coverImg"];
    $user=$_SESSION["user"];
    $userId=$user["id"];
    if($user==''){
        echo json_encode(array('code'=>'error','msg'=>'该用户还未进行登录，请登录'));
        return;
    };

    $sql="
        insert into t_together
            (title,tel,qq,weixin,toCity,fromCity,startDate,lastDays,limitNum,intro,coverImg,userId)
        values
            ('{$title}','{$tel}','{$qq}','{$weixin}','{$to}','{$from}','{$startDate}','{$lastDays}','{$limitNum}','{$intro}','{$coverImg}','{$userId}')
    ";
    $result=mysqli_query($conn,$sql);
    echo json_encode(array('code'=>'success','msg'=>'发布结伴成功'));
    