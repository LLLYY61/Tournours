<?php
    require "util/dbUtil.php";
    session_start();
    $content=$_REQUEST["content"];
    $tid=$_REQUEST["tid"];

    $user=$_SESSION["user"];
    $userId=$user["id"];
    if($user==''){
        echo json_encode(array('code'=>'error','msg'=>'该用户还未进行登录，请登录'));
        return;
    };
    
    $sql="
        insert into t_comment 
            (content,pubDate,userId,tourId)
        values
            ('{$content}',now(),'{$userId}','{$tid}')
    ";
    $result=mysqli_query($conn,$sql);
    echo json_encode(array('code'=>'success','msg'=>'添加成功'));