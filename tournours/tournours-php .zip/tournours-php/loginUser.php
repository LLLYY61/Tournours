<?php
    require "util/dbUtil.php";

    session_start();
    $userTel=$_REQUEST["tel"];
    $password=$_REQUEST["password"];

    $resultArr=Array();

    $sql="
        select 
            id,nikeName,userTel,password,userImgUrl
        from
            t_user
        where 
            userTel ='{$userTel}'
    ";
    $result=mysqli_query($conn,$sql);
    if($result ->num_rows == 0){
        $resultArr["code"] = "error";
        $resultArr["msg"] = "该手机号未进行注册";
        echo json_encode($resultArr);
        return;
    };

    $sql="
        select 
            id,nikeName,userTel,password,userImgUrl
        from 
            t_user
        where 
            userTel='{$userTel}' and password ='{$password}'
        ";
    $result=mysqli_query($conn,$sql);
    $user=mysqli_fetch_array($result,MYSQLI_ASSOC);
    if($result ->num_rows == 0){
        $resultArr["code"] = "error";
        $resultArr["msg"] = "密码错误";
        echo json_encode($resultArr);
    }else{
        $resultArr["code"] = "success";
        $resultArr["msg"] = "登录成功";
        $resultArr["user"]=$user;
        $_SESSION["user"]=$user;
        echo json_encode($resultArr);
    }
    