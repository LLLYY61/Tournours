<?php
    require "util/dbUtil.php";
    $resultArr=Array();
    session_start();
    $dest=$_REQUEST["dest"];
    $startDate=$_REQUEST["startDate"];

    $user=$_SESSION["user"];
    $userId=$user["id"];
    if($user==''){
        echo json_encode(array('code'=>'error','msg'=>'该用户还未进行登录，请登录'));
        return;
    };

    $sql="
        select 
            t.id tid,title,tel,qq,weixin,toCity,fromCity,startDate,lastDays,limitNum,intro,coverImg,
            nikeName,userImgUrl
        from 
            t_together t
        left join
            t_user u
        on
            t.userId=u.id
        where 
            fromCity='{$dest}' and startDate='{$startDate}'
    ";

    $result=mysqli_query($conn,$sql);
    while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
        array_push($resultArr,$row);
    }
    echo json_encode(array('code' => "success", "data" => $resultArr ));