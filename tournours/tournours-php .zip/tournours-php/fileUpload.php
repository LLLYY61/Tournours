<?php
   
    ini_set('date.timezone','Asia/Shanghai');
    // strtotime(now());
    // $_FILES["uploaderfile"];
    //判断是否有请求文件上传
    if($_FILES["uploadedfile"]==""){
        echo json_encode(array('code'=>'error','msg'=>'无文件上传'));
        return;
    }
    //若大于0，代表请求有错误
    if($_FILES["uploadedfile"]["error"]>0){
        echo json_encode(array('code'=>'error','msg'=>$_FILES["uploadedfile"]["error"]));
        return;
    }
    //存放文件的临时地址
    $tempUrl=$_FILES["uploadedfile"]["tmp_name"];
    $newFile="uploads/".strtotime("U").".".end(explode(".",$_FILES["uploadedfile"]["name"]));
    $baseUrl="img/";
    //服务器对于上传文件的存放文件夹需要有完全权限
    move_uploaded_file($tempUrl,$baseUrl.$newFile);
    echo json_encode(array('code'=>'success','imgUrl'=>$newFile));