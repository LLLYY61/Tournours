<?php
    require "util/dbUtil.php";
    $resultArr=Array();

    $tid=$_REQUEST["tid"];

    $sql="
        select 
            t.id,content,pubDate,userId,tourId,
            nikeName,userImgUrl
        from
            t_comment t
        left join 
            t_user u
        on
            t.userId=u.id
        where 
            tourId = '{$tid}'
        order by pubDate desc
    ";
    $result=mysqli_query($conn,$sql);
    while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
        array_push($resultArr,$row);
    }
    echo json_encode(array('code' => "success", "data" => $resultArr ));
   